# -*- coding: utf-8 -*-
import random

b = """
8827
12541
8364
4703
6827
5997
4775
7577
7088
870
14785
3910
5482
4872
2451
2167
2852
2367
1364
3189
2048
5692
3203
280
285
800
"""
a = map(lambda x: int(x), b.split("\n")[1:-1])
org_a = a
count_a = len(a)
avg_a = sum(a) / count_a
count = 1
final_result = []
# 26个分组，平均分配到5个代理服务器，分配策略为，先选出4组，每组有5个分组，最后遗留6个分组组成最后一个组。
# 循环4次，获取前四个组。
while count < 5:
    flag = True
    while flag:
        random_instance = random.sample(a, 5)
        # 获取与平均值上下相差100以内的合理分配。
        if avg_a / 5 - 100 < sum(random_instance) - avg_a * 5 < avg_a / 5 + 100:
            final_result.append(random_instance)
            flag = False
            for item in random_instance:
                del a[a.index(item)]
            print "{} group is found!".format(count + 1)
    count += 1

# 重新获取数列。
org_a = map(lambda x: int(x), b.split("\n")[1:-1])
# 获取标号
final_result = map(lambda x: map(lambda x: org_a.index(x) + 1, x), final_result)
# 补充遗留的6个分组作为最后一个组。
final_result.append(filter(lambda x: x not in reduce(lambda x, y: x + y, final_result), range(1, count_a + 1)))
# 打印信息。
for result in final_result:
    print sorted(result)
    print sum(map(lambda x: org_a[x - 1], result))
