# -*- coding: utf-8 -*-
import xlwt
import xlrd

def write_excel(path, sheets):
    wb = xlwt.Workbook()
    for sheet in sheets.keys():
        ws0 = wb.add_sheet(sheet)
        count = 0
        contents = sheets[sheet]
        while count < len(contents):
            inter_count = 0
            while inter_count < len(contents[count]):
                ws0.write(count, inter_count, contents[count][inter_count])
                inter_count += 1
            count += 1
    wb.save(path)
sheet_num = 0
sheets = {}
while sheet_num < 4:
    contents = map(lambda x: map(lambda y: y.value, x), xlrd.open_workbook("test1.xlsx").sheet_by_index(sheet_num).get_rows())[1:]
    dates = sorted(list(set(map(lambda x: x[1], contents))))
    dates.insert(0, "")
    inserts_contents = [dates]
    group_id = 1
    while group_id < 27:
        group_value = ["coms{}".format(group_id)]
        count = 0
        while count < 30:
            try:
                group_value.append(int(contents[(group_id - 1)*30 + count][2]))
            except ValueError:
                group_value.append(str(contents[(group_id - 1) * 30 + count][2]))
            count += 1
        inserts_contents.append(group_value)
        group_id += 1
    for value in inserts_contents:
        print value
    sheets["sheet{}".format(sheet_num)] = inserts_contents
    sheet_num += 1

write_excel("test11.xls", sheets)