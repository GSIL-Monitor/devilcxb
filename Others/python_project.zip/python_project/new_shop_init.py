# -*- coding: utf-8 -*-
import xlrd
import os
import xlwt


def convert_to_date(value):
    return "{}/{}/{}".format(value[0], value[1], value[2])


def write_excel(path, contents):
    wb = xlwt.Workbook()
    ws0 = wb.add_sheet('sheet0')
    count = 0
    fmt = 'YYYY/M/D'
    style = xlwt.XFStyle()
    style.num_format_str = fmt
    while count < len(contents):
        inter_count = 0
        while inter_count < len(contents[count]):
            if inter_count == 2:
                ws0.write(count, inter_count, contents[count][inter_count], style=style)
            else:
                ws0.write(count, inter_count, contents[count][inter_count])
            inter_count += 1
        count += 1
    wb.save(path)


province_map = {u"四川": 1,
                u"湖南": 2,
                u"广东": 3,
                u"山东": 4,
                u"深圳": 5,
                u"重庆": 6,
                u"北京": 7,
                u"浙江": 8,
                u"河北": 9,
                u"辽宁": 10,
                u"湖北": 11,
                u"河南": 12,
                u"上海": 13,
                u"陕西": 14,
                u"吉林": 15,
                u"贵州": 16,
                u"天津": 17,
                u"广西": 18,
                u"甘肃": 19,
                u"江西": 20,
                u"安徽": 21,
                u"江苏": 22,
                u"福建": 23,
                u"黑龙江": 24
                }
province_map = {v: k for k, v in province_map.items()}

path = r"D:\Work\201707\20170719\finance"
current_tickets = xlrd.open_workbook(os.path.join(path, "udticket.xlsx")).sheet_by_index(0).get_rows()
current_tickets = map(lambda x: x, current_tickets)[1:]
print len(current_tickets)
print len(set(map(lambda x: x[0].value, current_tickets)))
history_tickets = xlrd.open_workbook(os.path.join(path, "udticket_his.xlsx")).sheet_by_index(0).get_rows()
history_tickets = map(lambda x: x, history_tickets)[1:]
shops_from_history = map(lambda x: x[0].value, history_tickets)
filter_items = []
for item in current_tickets:
    if item[0].value not in shops_from_history:
        filter_items.append(item)
    elif item[2].value < history_tickets[shops_from_history.index(item[0].value)][2].value:
        history_tickets[shops_from_history.index(item[0].value)] = item
print len(filter_items)
history_tickets = history_tickets + filter_items
shops_total_from_db = map(lambda x: x[0].value, history_tickets)
print len(shops_total_from_db)
items_from_finance = xlrd.open_workbook(os.path.join(path, "finance.xlsx")).sheet_by_index(0).get_rows()
items_from_finance = map(lambda x: x, items_from_finance)[1:]
print '"门店编号"', ',"地区"', ',"接入时间"'
contents = []
for item in items_from_finance:
    shop_id = item[0].value
    if shop_id in shops_total_from_db:
        value = history_tickets[shops_total_from_db.index(shop_id)]
        print '"' + value[0].value + '","', province_map[
                                                int(value[1].value.replace("xccoms", ""))] + '","', convert_to_date(
            xlrd.xldate_as_tuple(value[2].value, 0)) + '"'
        contents.append([value[0].value, province_map[int(value[1].value.replace("xccoms", ""))], value[2].value])
write_excel("test.xls", contents)
