# -*- coding: utf-8 -*-
import xlrd
import os
import collections


class HandleDailyReport(object):
    def __init__(self, xls_path, ali_weichat_success_failure_record_file, detailed_failure_file, manual_code_file):
        self.xls_path = xls_path
        self.ali_weichat_success_failure_record_file = ali_weichat_success_failure_record_file
        self.detailed_failure_file = detailed_failure_file
        self.manual_code_file = manual_code_file

    def read_file(self, xls_file):
        return xlrd.open_workbook(xls_file).sheet_by_index(0).get_rows()

    def get_ali_weichat_success_failure_record(self):
        records = filter(lambda x: x[1].value == u"支付宝" or x[1].value == u"微信", map(lambda x: x, self.read_file(
            os.path.join(self.xls_path, self.ali_weichat_success_failure_record_file))))
        ali_records = filter(lambda x: x[1].value == u"支付宝", records)
        ali_records_success = filter(lambda x: x[2].value == u'成功', ali_records)
        ali_records_failure = filter(lambda x: x[2].value == u'失败', ali_records)
        ali_records_success_sum = sum(map(lambda x: int(x[3].value), ali_records_success))
        ali_records_failure_sum = sum(map(lambda x: int(x[3].value), ali_records_failure))
        weichat_records = filter(lambda x: x[1].value == u"微信", records)
        ali_weichat_success = filter(lambda x: x[2].value == u'成功', weichat_records)
        ali_weichat_failure = filter(lambda x: x[2].value == u'失败', weichat_records)
        ali_weichat_success_sum = sum(map(lambda x: int(x[3].value), ali_weichat_success))
        ali_weichat_failure_sum = sum(map(lambda x: int(x[3].value), ali_weichat_failure))
        return {u"支付宝成功": ali_records_success_sum, u"支付宝失败": ali_records_failure_sum, u"微信成功": ali_weichat_success_sum,
                u"微信失败": ali_weichat_failure_sum, }

    def get_failure_summary(self):
        summary = {u"微信": {}, u"支付宝": {}}
        records = filter(lambda x: x[1].value == u"支付宝" or x[1].value == u"微信", map(lambda x: x, self.read_file(
            os.path.join(self.xls_path, self.detailed_failure_file))))
        failure_reasons = [u"支付失败,请重新支付", u"USERPAYING需要用户输入支付密码", u"每个二维码仅限使用一次", u"付款码无效", u"订单不存在", u"未支付,请重新支付",
                           u"银行卡可用余额不足（如信用卡则为可透支额度不足），请核实后再试", u"支付失败，获取顾客账户信息失败，请顾客刷新付款码后重新收款，如再次收款失败，请联系管理员处理。",
                           u"已关闭,请重新支付", u"退款失败,交易失败", u"付款码已过期，请刷新再试", u"服务器请求失败或超时(YT)", u"二维码已经过期，请刷新再试",
                           u"订单已转入退款,请重新支付", u"付款码已过期，请刷新再试", u"二维码已过期，请刷新再试", u"操作失败，服务器网络异常"]
        ali_records = filter(lambda x: x[1].value == u"支付宝", records)
        ali_records_failures = map(lambda x: x[2].value, ali_records)
        ali_records_failures_sum = map(lambda x: int(x[3].value), ali_records)
        for failure_reason in failure_reasons:
            sum = 0
            count = 0
            while count < len(ali_records_failures):
                if failure_reason in ali_records_failures[count]:
                    sum += ali_records_failures_sum[count]
                count += 1
            summary[u"支付宝"][failure_reason] = sum
        new_issues = {u"微信": [], u"支付宝": []}
        except_issues = [u"用户支付中", u"创建", u"退款成功"]
        count = 0
        while count < len(ali_records_failures):
            if not filter(lambda x: x in ali_records_failures[count], failure_reasons):
                if ali_records_failures[count] not in new_issues[u"支付宝"]:
                    if not filter(lambda x: x in ali_records_failures[count], except_issues):
                        new_issues[u"支付宝"].append(ali_records_failures[count])
            count += 1
        weichat_records = filter(lambda x: x[1].value == u"微信", records)
        weichat_records_failures = map(lambda x: x[2].value, weichat_records)
        weichat_records_failures_sum = map(lambda x: int(x[3].value), weichat_records)
        for failure_reason in failure_reasons:
            sum = 0
            count = 0
            while count < len(weichat_records_failures):
                if failure_reason in weichat_records_failures[count]:
                    sum += weichat_records_failures_sum[count]
                count += 1
            summary[u"微信"][failure_reason] = sum
        count = 0
        while count < len(weichat_records_failures):
            if not filter(lambda x: x in weichat_records_failures[count], failure_reasons):
                if weichat_records_failures[count] not in new_issues[u"支付宝"]:
                    if not filter(lambda x: x in weichat_records_failures[count], except_issues):
                        new_issues[u"微信"].append(weichat_records_failures[count])
            count += 1
        return summary, new_issues

    def get_manual_code(self):
        manual_code_records = map(lambda x: x, self.read_file(os.path.join(self.xls_path, self.manual_code_file)))[1:]
        sucess_manual_code_records = filter(lambda x: x[6].value == u"成功", manual_code_records)
        failure_manual_code_records = filter(lambda x: x[6].value == u"失败", manual_code_records)
        shops = map(lambda x: x[4].value, manual_code_records)
        manual_code_times = collections.Counter(shops).items()
        manual_code_times_map = {}
        for shop, times in manual_code_times:
            manual_code_times_map[u"商家" + shop] = [u"共录入" + str(times) + u"次", filter(lambda x: x[4].value == shop, manual_code_records)[0][9].value.replace("xccoms", u"分组")]
        failure_manual_code_record_summary = {}
        for failure_manual_code_record in failure_manual_code_records:
            failure_manual_code_record_summary[u"商家:" + failure_manual_code_record[4].value] = [
                u"小票号:" + failure_manual_code_record[1].value,
                failure_manual_code_record[7].value,
                u"分组:" + failure_manual_code_record[9].value]
        return manual_code_times_map, failure_manual_code_record_summary

    def main(self):
        ali_weichat_success_failure_records = self.get_ali_weichat_success_failure_record()
        print "##############################支付概况##############################"
        for i in ali_weichat_success_failure_records.keys():
            print i, ali_weichat_success_failure_records[i]
        print "###################################################################"
        print "##############################支付失败详情##########################"
        failure_summary, new_issues = self.get_failure_summary()
        for key in failure_summary.keys():
            for sub_key in failure_summary[key].keys():
                print key, sub_key, failure_summary[key][sub_key]
        print "###################################################################"
        print "############################new issue##############################"
        for key in new_issues.keys():
            for i in new_issues[key]:
                print "new issue " + key + " " + i
        print "###################################################################"
        print "##############################人工输入code记录######################"
        manual_code_times_map, failure_manual_code_record_summary = self.get_manual_code()
        for key in manual_code_times_map.keys():
            print key, reduce(lambda x, y: x + " "+ y, manual_code_times_map[key])
        print "###################################################################"
        print "##############################不应该录入code记录####################"
        for key in failure_manual_code_record_summary:
            print key, reduce(lambda x, y: x + " " + y, failure_manual_code_record_summary[key])
        print "###################################################################"


HandleDailyReport = HandleDailyReport(r"C:\Users\chixiaobo\Desktop\try\1.2.2\0706", "payresult_full.xlsx", "payresult_failed.xlsx",
                                      "voucher_input.xlsx")
HandleDailyReport.main()
