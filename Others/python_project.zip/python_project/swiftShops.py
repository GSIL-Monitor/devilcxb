# -*- coding: utf8 -*-
import urllib2
import urllib
import json
import cookielib
import os
import logging
import sys
from poster.encode import multipart_encode, MultipartParam
from poster.streaminghttp import register_openers
import poster.streaminghttp as streaminghttp

logging.basicConfig(level=logging.INFO)


def export(data, page_number, logo_name):
    data = {"expDatas": data}
    url = "https://citicmch.swiftpass.cn/cms/base/merchant/exportQr"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0",
               "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
               "Accept-Language": "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3",
               "Accept-Encoding": "gzip, deflate, br",
               "Referer": "https://citicmch.swiftpass.cn/system/index",
               "Content-Type": "application/x-www-form-urlencoded"
               }
    print "##################start to download {} page###################".format(page_number)
    # url = url + "?hisFlag=0&acceptOrgId=&" + "expDatas={}".format(data["expDatas"]).replace(": u'", ":'").replace(" ", "") + "&isMerchantQr=true&qrType=2&rgbHex=00bf00&qrLogo={}&mchLogo=&payTypes=1&payTypes=2&qrMark=".format(logo_name)
    # url = url + "?hisFlag=0&acceptOrgId=&" + "expDatas={}".format(data["expDatas"]).replace(": u'", ":'").replace(" ", "")
    data_to_post = {"hisFlag": 0,
            "acceptOrgId": "",
            "expDatas": data["expDatas"],
            "isMerchantQr": True,
            "qrType": 1,
            "rgbHex": "00bf00",
            "resolution": 1,
            "qrLogo": "",
            "mchLogo": "",
            "payTypes": 1,
            "qrMark": ""
            }
    url = url + "?hisFlag=0&acceptOrgId=&" + "expDatas={}".format(data["expDatas"]).replace(": u'", ":'").replace(" ",
                                                                                                                  "") + "&isMerchantQr=true&qrType=1&rgbHex=00bf00&resolution=1&qrLogo=&mchLogo=&payTypes=1&payTypes=2&payTypes=3&qrMark="
    print url
    req = urllib2.Request(url, headers=headers)
    # results = urllib2.urlopen(req, data=urllib.urlencode(data_to_post)).read()
    results = urllib2.urlopen(req).read()
    # urllib.urlretrieve(url, "{}.zip".format(page_number))
    with open(os.path.join(r"D:\Devil\python_project\swiftShops_20171115", "{}.zip".format(page_number)),
              "wb") as contents:
        contents.write(results)
    print "##################end to download {} page###################".format(page_number)


def get_result(logo_name=None):
    false = False
    null = None
    url = 'https://citicmch.swiftpass.cn/cms/base/merchant/qrDatagrid.json'
    data = {
        "beginCreateTime": "2017-08-04 00:00:00",
        "pageSize": "30",
        "total": "100000000",
        "page": "1",
        "pageNumber": "1",
        "rows": "50"
    }
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
               }
    # req = urllib2.Request(url=url, headers=headers)
    # pages = eval(urllib2.urlopen(req, data=json.dumps(data)).read())["pages"]
    # print "total page number is: {}".format(pages)
    count = 1
    while count <= 1123:
        data["pageNumber"] = str(count)
        req = urllib2.Request(url=url, headers=headers)
        result = urllib2.urlopen(req, data=urllib.urlencode(data)).read()
        print result
        result = eval(urllib2.urlopen(req, data=urllib.urlencode(data)).read())
        print result
        shops = map(lambda x: handle_data(x), result["rows"])
        # print "shops: {}".format(shops)
        export(shops, count, logo_name=logo_name)
        count += 1


def handle_data(data):
    new_data = {}
    import re
    new_data["merchantName"] = urllib.quote(data["merchantName"])
    new_data["merchantId"] = data["merchantId"]
    return new_data


def post_logo_file():
    url = "https://citicmch.swiftpass.cn/cms/base/qrBatch/uploadImg"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
               # "Accept": "application/json, text/javascript, */*; q=0.01"
               }
    # from upload_file import UploadFile_post
    # UploadFile_post = UploadFile_post()
    result = get_upload_result(url=url, filepath='LOGO.jpg', parametername='accessory', headers_passed=headers)
    return result


def get_upload_result(url, filepath, parametername, data=None, headers_passed=None, return_result=True, filename=None,
                      selection_choice_list=None, ssl_connection=False):
    """
    此方法用于上传文件并且或者返回结果
    :param url: 请求的URL
    :param filepath: 请求的文件的绝对路径
    :param parametername: 上传文件接口定义的参数名称
    :param return_result: 是否返回测试结果
    :param filename: 文件名称，上传时显示的文件名称，请不要随意填写
    :param data: 需要传递请求参数
    :param headers_passed: 需要加入的请求头文件内容, 这个地方一定不要加入Content-Type的字段，否则会覆盖自动获取的headers
    :param selection_choice_list: 需要传递额外的参数例如{"devicenos": ["2440fc","36c4ee", "2b01db"]}
    :return: 返回上传文件的json result
    """
    if headers_passed:
        if "Content-Type" in headers_passed.keys():
            logging.error("Content-Type is no needed since it will be generated automatically via the framework!")
            sys.exit(1)

    # # # 在 urllib2 上注册 http 流处理句柄
    # from poster.streaminghttp import StreamingHTTPHandler, StreamingHTTPRedirectHandler, StreamingHTTPSHandler
    # handlers = [StreamingHTTPHandler, StreamingHTTPRedirectHandler, StreamingHTTPSHandler]
    # opener = urllib2.build_opener(*handlers)
    # urllib2.install_opener(opener)

    # headers 包含必须的 Content-Type 和 Content-Length
    # datagen 是一个生成器对象，返回编码过后的参数
    items = []
    if selection_choice_list:
        for key in selection_choice_list.keys():
            if type(selection_choice_list[key]) == dict or type(selection_choice_list[key]) == list:
                for item in selection_choice_list[selection_choice_list.keys()[0]]:
                    items.append(MultipartParam(selection_choice_list.keys()[0], item))
            else:
                items.append(MultipartParam(key, selection_choice_list[key]))
        if filename:
            pass
        else:
            filename = filepath.replace("/", "\\").split("\\")[-1]
        items.append(MultipartParam(parametername, filename=filename, fileobj=open(filepath, "rb")))
        datagen, headers = multipart_encode(items)
    else:
        datagen, headers = multipart_encode({parametername: open(filepath, "rb")})

    datagen = reduce(lambda x, y: x + y, map(lambda x: x, datagen))
    # print datagen

    # 创建请求对象
    if data:
        data = urllib.urlencode(data)
        if "?" not in url:
            url = url + "?" + data
        else:
            url = url + "&" + data
    # print url
    # print datagen
    request = urllib2.Request(url, datagen, headers)
    if headers_passed:
        for header in headers_passed:
            request.add_header(header, headers_passed[header])
    # 实际执行请求并取得返回
    gcontext = None
    null = None
    true = True
    false = False
    print request.header_items()
    if ssl_connection:
        import ssl
        gcontext = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    if return_result:
        print urllib2.urlopen(request, context=gcontext).read()
        return eval(urllib2.urlopen(request, context=gcontext).read())
    else:
        print urllib2.urlopen(request, context=gcontext).read()


def get_logo_file(logo_file_name):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
               "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
               }
    # url = 'https://citicmch.swiftpass.cn/pic/mchQrlogo/2729ad6054c041e2a13dad9c500d22c9.jpg'
    # print url
    # req = urllib2.Request(url, headers=headers)
    # print urllib2.urlopen(req).read()
    url = 'https://citicmch.swiftpass.cn/pic/mchQrlogo' + '/' + logo_file_name
    print url
    req = urllib2.Request(url, headers=headers)
    if urllib2.urlopen(req).read():
        return True
    return False


def login_urllib():
    print "##################登陆######################"
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookielib.CookieJar()))
    url = "https://citicmch.swiftpass.cn/login_pc"
    data = {"userName": "102552009605",
            "password": "yt123456"}
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
               "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
               }
    req = urllib2.Request(url, headers=headers)
    opener.open(req, data=urllib.urlencode(data)).read()
    urllib2.install_opener(opener)
    print "################登陆成功####################"


if __name__ == '__main__':
    login_urllib()
    get_result()
    # logo_file_name = post_logo_file()["msg"]
    # # print get_logo_file(logo_file_name)
    # logo_file_name = '2729ad6054c041e2a13dad9c500d22c9.jpg'
    # if get_logo_file(logo_file_name=logo_file_name):
    #     get_result(logo_file_name)
