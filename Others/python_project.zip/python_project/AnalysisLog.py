#!/usr/bin/env python
# -*- coding:utf-8 -*- 
# Author:  yangwei
# datetime:  2017/9/18
import os
import uuid

import sys

from FtpOperations import downlaod_log_files, compare_date, new_dirs
import chardet
import re

import datetime, time

file_ftp_path_info = "/LOGDATA/RETAILCOM{}"


def time_differ(timeStrb='2017-09-21 12:55:05', timeStra='2017-09-21 13:15:05'):
    '''
     @传入是时间格式如'2017-09-21 12:55:05'
     :return 两个时间秒差
     '''
    if timeStra <= timeStrb:
        return 0
    ta = time.strptime(timeStra, "%Y-%m-%d %H:%M:%S")
    tb = time.strptime(timeStrb, "%Y-%m-%d %H:%M:%S")
    y, m, d, H, M, S = ta[0:6]
    dataTimea = datetime.datetime(y, m, d, H, M, S)
    y, m, d, H, M, S = tb[0:6]
    dataTimeb = datetime.datetime(y, m, d, H, M, S)
    secondsDiff = (dataTimea - dataTimeb).seconds
    return secondsDiff
    # # 两者相加得转换成分钟的时间差
    # minutesDiff = round(secondsDiff / 60, 1)
    # return minutesDiff


def is_seconds_bigger_30(timeStrb, timeStra):
    """
        判断时间间隔 轮询每次间隔应该在30到50之间
    :param timeStrb:
    :param timeStra:
    :return:
    """
    return 30 <= time_differ(timeStrb, timeStra) <= 50


def walk_dir(root_path, days):
    """
        文件筛选
    :param root_path:
    :param days:
    :return:
    """
    if not os.path.isdir(root_path):
        return
    start_date = datetime.datetime.now() - datetime.timedelta(days=int(days))
    start_date = start_date.strftime("%Y%m%d")
    file_dirs = os.listdir(root_path)
    files = []
    dir_infos = []
    for index, name in enumerate(file_dirs):
        path_tmp = os.path.join(root_path, name)
        if os.path.isdir(path_tmp):
            dir_infos.append(walk_dir(path_tmp, days))
        else:
            date_tmp = name.split('_')[1].replace('-', '')
            if compare_date(start_date, date_tmp) < 0:
                os.remove(path_tmp)
            else:
                files.append(path_tmp)

    return {"path": root_path, "dir_infos": dir_infos, 'files': files}


def add_count(count, commodity_infos):
    """
        出现数量累加
    :param count:
    :param commodity_infos:
    :return:
    """
    for key, value in commodity_infos.items():
        if len(value) < 2 or len(value) > 4:
            continue
        elif len(value) == 2:
            if is_seconds_bigger_30(value[0], value[1]):
                print 'commodity_infos:{} '.format(commodity_infos)
                count += 1
                break
        elif len(value) == 3:
            if is_seconds_bigger_30(value[0], value[1]) and is_seconds_bigger_30(value[1], value[2]):
                print 'commodity_infos:{} '.format(commodity_infos)
                count += 1
                break
        elif len(value) == 4:
            if is_seconds_bigger_30(value[0], value[1]) and is_seconds_bigger_30(value[1], value[
                2]) and is_seconds_bigger_30(value[2], value[3]):
                print 'commodity_infos:{} '.format(commodity_infos)
                count += 1
                break
    return count


class AnalysisLogPOS(object):
    log_file_root_path = r'product_logs'

    def get_product_logs(self, log_file_root_path=None, days=0):
        if not log_file_root_path:
            log_file_root_path = self.log_file_root_path
        return walk_dir(log_file_root_path, days)

    def out_put_analysislog(self, log_file_root_path=None, days=0, account=""):
        if not log_file_root_path:
            log_file_root_path = self.log_file_root_path
        file_infos = self.get_product_logs(log_file_root_path, days)
        results_dir = os.path.join(log_file_root_path, "../../results")
        new_dirs(results_dir)
        result_file_path = '{}/result{}.txt'.format(results_dir, time.strftime('%Y%m%d%H%M%S', time.localtime()))
        with open(result_file_path, 'w') as f:
            for jms_loginfo in file_infos.get('dir_infos'):
                jms_no = jms_loginfo.get('path').split('\\')[-1]
                if account and not account == jms_no:
                    continue
                total_count = 0
                for logfile in jms_loginfo.get('files'):
                    result_info = self.read_log_file(logfile)
                    total_count += result_info.get('count')
                    f.write('{}:{}\n'.format(jms_no, result_info))
                f.write('{} appear total coutn is {}\n'.format(jms_no, total_count))
                f.flush()
                if account:
                    break
        print "please see the detail info in {}".format(result_file_path)

    def read_log_file(self, file_path=r''):
        count = 0
        key_word = u'INFO com.dhc.ipos.retail.service.impl.TicketServiceImpl 插入前置表判定称重商品条码：(.*)\n$'
        end_key_word = u'INFO com.dhc.ipos.retail.service.impl.TicketServiceImpl 插入小票表判定称重商品条码'
        uplaod_success_key_word = u'com.dhc.ipos.retail.service.impl.TicketServiceImpl 小票(.*)上传成功！\n$'
        with open(file_path, mode='r') as log_file:
            commodity_infos = {}
            lines_infos = log_file.readlines()
        for str_line in lines_infos:
            try:
                encoding = chardet.detect(str_line).get('encoding')
                str_line = str_line.decode(encoding)
            except Exception, e:
                # print e.message
                pass
            if re.findall(key_word, str_line):
                commodity_no = re.findall(key_word, str_line)[0]
                log_time = str_line.split(',')[0]
                if commodity_infos and time_differ(commodity_infos.get('start_time'), log_time) > 120:
                    # 上一次轮询完成到下一次轮询开始不会超过两分钟
                    count = add_count(count, commodity_infos)
                    commodity_infos = {}
                if not commodity_infos:
                    commodity_infos['start_time'] = log_time  # 设置每次轮询的开始时间
                datetims = commodity_infos.get(commodity_no) or []
                datetims.append(log_time)
                commodity_infos[commodity_no] = datetims
            try:
                if re.findall(uplaod_success_key_word, str_line) or end_key_word in str_line:
                    count = add_count(count, commodity_infos)
                    commodity_infos = {}
            except Exception, e:
                # print e.message
                pass

        else:
            add_count(count, commodity_infos)
        # tem_file_path = file_path.split("\\")[-1]
        end_tmp_file_path = '{}/{}/{}'.format(file_ftp_path_info.format(file_path.split("\\")[-3].replace("com", "")),
                                              file_path.split("\\")[-2],
                                              file_path.split("\\")[-1])
        return {"file_path": end_tmp_file_path, "count": count}


if __name__ == '__main__':
    current = os.getcwd()
    sys.path.append(current)
    # if len(sys.argv) < 2:
    #     print u"请至少输入分组编号"
    #
    # group_no = int(sys.argv[1])
    # try:
    #     days = int(sys.argv[2])
    # except:
    #     days = 1
    #
    # try:
    #     account = sys.argv[3]
    # except:
    #     account = ""

    group_no=1
    days = 10
    account = "Z001584"

    print time.strftime('%Y%m%d%H%M%S', time.localtime())
    # group_no = 5
    # days = 4
    # account = "A000357"
    root_path = 'coms{}'.format(group_no)
    product_logs_path = os.path.join(current, 'product_logs')
    new_dirs(product_logs_path)
    root_path = os.path.join(product_logs_path, root_path)
    downlaod_log_files(group_no, days, account, local_root_path=root_path)
    # walk_dir(root_path)
    # path = 'D:\\workspace\\tests\\product_logs\\A000004\\0001_2017-09-10_ilead_ria.log'

    test = AnalysisLogPOS()
    test.out_put_analysislog(root_path, days, account)
    print time.strftime('%Y%m%d%H%M%S', time.localtime())
