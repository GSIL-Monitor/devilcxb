# -*- coding: utf-8 -*-
import sys
import os
import urllib
import urllib2
import cookielib

#sys.path.append(os.path.join(os.environ.get("WORKSPACE"), "VersionControl/package"))
# sys.path.append(r"D:\validation\09_Automatic_Test\projects\NLS\VersionControl\package")
from jira.client import JIRA
import logging

logging.basicConfig(level=logging.INFO)


class HandleJira(object):
    def __init__(self, server, username, password):
        __options = None
        __oauth = None
        __validate = None
        __async = False
        __logging = False
        self.jira_client = JIRA(server, __options, (username, password), __oauth, __validate, __async, __logging)

    def create_version(self, project_key, project_id, version_name, description=None):
        project = self.jira_client.project(project_id)
        project_versions = project.versions
        for project_version in project_versions:
            if project_version.name == version_name:
                return True
        return self.jira_client.create_version(name=version_name, project=project_key, description=description)

    def get_issues_by_fixed_version(self, project_name, fixed_version):
        issues = self.jira_client.search_issues(
                              jql_str='project = NLS AND status in (未开始, "In Progress", Reopened, 处理中, 代码评审中, 重开, 推迟处理, 挂起)')
        return issues

    def write_email_for_testing(self, contents):
        File = open(os.path.join(os.environ.get("WORKSPACE"), "params.txt"), "w")
        File.write("Subject={}_{}_Debug提测\n".format(os.environ.get("Version"), os.environ.get("Test_Loop")))
        File.write(
            'Mail_Content=<br />' + contents + '<br /><br />' + os.environ.get("Note").replace("\n", "<br />") + '<br /><br />' + "\n")
        if os.environ.get("FixEnvrionment") == "True":
            File.write("SendMail_flag=False")
        else:
            File.write("SendMail_flag=True")
        File.close()

    def login_urllib(self):
        print "##################登陆######################"
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookielib.CookieJar()))
        url = "https://solution.yatang.cn/jira/login.jsp"
        data = {"os_username": "chixiaobo",
                "os_password": "DEVIL_cxb789",
                "login":"登陆"}
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
                   "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
                   }
        req = urllib2.Request(url, headers=headers)
        opener.open(req, data=urllib.urlencode(data)).read()
        urllib2.install_opener(opener)
        print "################登陆成功####################"
        return opener

if __name__ == '__main__':
    HandleJira = HandleJira("https://solution.yatang.cn/jira", "chixiaobo", "DEVIL_cxb789")
    opener = HandleJira.login_urllib()
    version_name = "{}_{}_Debug".format(os.environ.get("Version"), os.environ.get("Test_Loop"))
    issues = HandleJira.get_issues_by_fixed_version("NLS", version_name)
    for issue in issues:
        print issue
        # print opener.open("https://solution.yatang.cn/jira/browse/{}?page=com.atlassian.jira.plugin.system.issuetabpanels:changehistory-tabpanel".format(str(issue))).read()
        break
