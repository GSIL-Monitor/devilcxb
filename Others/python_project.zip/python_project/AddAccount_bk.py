# -*- coding: utf-8 -*-
from selenium import webdriver
import os
import time
import urllib
import urllib2
import sys
import xlrd
from selenium.webdriver.support.select import Select


class CreateAccount(object):
    def __init__(self, username, password, xls_file, main_domain):
        self.xls_file = xls_file
        self.username = username
        self.password = password
        self.main_domain = main_domain
        self.browser = webdriver.Ie()
        self.provinces_map = self.provinces_map()
        self.operation_centers = self.get_operation_center()
        cookie = self.get_cookie()
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Accept-Language": "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3",
            "Cookie": "{}={}".format(cookie[0], cookie[1]),
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            "__REQUEST_TYPE": "AJAX_REQUEST",
            "X-Requested-With": "XMLHttpRequest",
            # "Referer": "{}/authUserAction.do?method=editUser&userId=".format(domain)
        }
        self.jms_data = {
            "titleFlag	": "add",
            # "ltdName": "小超第二运营中心",
            # "ltdId": "2",
            # "bankAccount": "test11",
            # "alliBusiName": "test11",
            "alliBusiIdcard": "",
            # "alliBusiId": {0: "test11", 1: "test11"},
            "accountDate": "3"
        }
        self.add_user_data = {
            "userName": "test11",
            "userId": "",
            "userCode": "test11",
            "positionId": "",
            "orgSel": "雅堂小超",
            "orgId": "T0",
            "isFinance	": "0",
            "createDate": "",
            "createBy": {0: "admin", 1: "admin"}
        }

    def get_operation_center(self):
        operation_centers = {u"四川": "四川子公司运营部",
                        u"湖南": "湖南子公司运营部",
                        u"广东": "广东子公司运营部",
                        u"山东": "山东子公司运营部",
                        u"深圳": "深圳子公司运营部",
                        u"重庆": "重庆子公司运营部",
                        u"北京": "北京子公司运营部",
                        u"浙江": "浙江子公司运营部",
                        u"河北": "河北子公司运营部",
                        u"辽宁": "辽宁子公司运营部",
                        u"湖北": "湖北子公司运营部",
                        u"河南": "河南子公司运营部",
                        u"上海": "上海子公司运营部",
                        u"陕西": "陕西子公司运营部",
                        u"吉林": "吉林子公司运营部",
                        u"贵州": "贵州子公司运营部",
                        u"天津": "天津子公司运营部",
                        u"广西": "广西子公司运营部",
                        u"甘肃": "甘肃子公司运营部",
                        u"江西": "江西子公司运营部",
                        u"安徽": "安徽子公司运营部",
                        u"江苏": "江苏子公司运营部",
                        u"福建": "福建子公司运营部",
                        u"黑龙江": "黑龙江子公司运营部"
                        }
        return operation_centers
    def provinces_map(self):
        province_map = {u"四川": 1,
                        u"湖南": 2,
                        u"广东": 3,
                        u"山东": 4,
                        u"深圳": 5,
                        u"重庆": 6,
                        u"北京": 7,
                        u"浙江": 8,
                        u"河北": 9,
                        u"辽宁": 10,
                        u"湖北": 11,
                        u"河南": 12,
                        u"上海": 13,
                        u"陕西": 14,
                        u"吉林": 15,
                        u"贵州": 16,
                        u"天津": 17,
                        u"广西": 18,
                        u"甘肃": 19,
                        u"江西": 20,
                        u"安徽": 21,
                        u"江苏": 22,
                        u"福建": 23,
                        u"黑龙江": 24
                        }
        return province_map

    def get_domain(self, province):
        if province == u"四川":
            domain = "{}/coms".format(self.main_domain)
        else:
            domain = "{}/coms{}".format(self.main_domain, self.provinces_map[province])
        domain = "{}/coms{}".format(self.main_domain, self.provinces_map[province])
        return domain

    def get_add_jms_url(self, domain):
        add_jms_url = "{}/alliInfoAction.do?method=doSave&opType=add".format(domain)
        return add_jms_url

    def add_account_url(self, domain):
        add_account_url = "{}/authUserAction.do?method=saveUser".format(domain)
        return add_account_url

    def get_cookie(self):
        self.browser.get("{}/account/index.jsp".format(self.main_domain))
        self.browser.maximize_window()
        self.browser.find_element_by_id("username").send_keys(self.username)
        self.browser.find_element_by_id("password").send_keys(self.password)
        self.browser.find_element_by_class_name("loginBtn").click()
        count = 1
        while not self.browser.find_element_by_class_name("icon-home"):
            count += 1
            if count == 10:
                print "home page can not open!"
                sys.exit(1)
        cookie = self.browser.get_cookies()[0]
        cookie_name = cookie["name"]
        cookie_value = cookie["value"]
        return cookie_name, cookie_value

    def close_broswer(self):
        self.browser.close()

    def request_url(self, url, data, headers):
        Req = urllib2.Request(url, headers=headers)
        return urllib2.urlopen(Req, data=urllib.urlencode(data)).read()

    def add_jms(self, jms_url, jms_data, jms_headers):
        result = self.request_url(jms_url, jms_data, jms_headers)
        print result
        try:
            result = eval(result)
            if result["__WARNMSGS"][0]["__WARNMSG"] == u"保存成功":
                print u"加盟商增加成功！"
        except:
            print u"增加加盟商失败！"

    def add_user_account(self, user_data, user_headers):
        result = self.request_url(self.add_jms_url, user_data, user_headers)
        print result
        try:
            result = eval(result)
            if result["__WARNMSGS"][0]["__WARNMSG"] == u"保存成功":
                print u"加盟商增加成功！"
        except:
            print u"增加加盟商失败！"

    def get_jms_info(self):
        jms_infos = xlrd.open_workbook(self.xls_file).sheet_by_index(0).get_rows()
        return jms_infos

    def main(self):
        jms_infos = map(lambda x: x, self.get_jms_info())[1:]
        for jms_info in jms_infos:
            jms_info = map(lambda x: x.value, jms_info)
            jms_no = jms_info[1].split(".")[1].encode("utf-8")
            jms_name = jms_info[2].encode("utf-8")
            jms_owner = jms_info[3]
            province = jms_info[4].strip()
            try:
                com = self.provinces_map[province]
            except IndexError:
                continue
            if not (jms_no and jms_name and jms_owner and province):
                continue
            domain = self.get_domain(province)
            self.jms_data["ltdName"] = self.operation_centers[province]
            self.jms_data["ltdId"] = com
            self.jms_data["bankAccount"] = "XC{}".format(jms_no)
            self.jms_data["alliBusiName"] = jms_name
            self.jms_data["alliBusiId"] = {0: "jms_" + jms_no, 1: "jms_" + jms_no}
            jms_url = self.get_add_jms_url(domain)
            if com == 1:
                print self.jms_data
                print self.headers
                print jms_url
                self.headers["Referer"] = "{}/authUserAction.do?method=editUser&userId=".format(domain)
                self.add_jms(jms_url=jms_url, jms_data=self.jms_data, jms_headers=self.headers)
                break
        self.close_broswer()


if __name__ == '__main__':
    main_domain = "http://xcsit2.yatang.cn:8680"
    CreateAccount = CreateAccount(username="admin", password="222222", xls_file="jms.xlsx", main_domain=main_domain)
    CreateAccount.main()