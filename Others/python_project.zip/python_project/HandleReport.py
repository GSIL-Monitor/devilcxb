# -*- coding: utf-8 -*-
import xlrd
import os


class HandleReport(object):
    def __init__(self, csv_path):
        self.csv_path = csv_path

    def get_csv_files(self):
        csv_fils = filter(lambda x: x.endswith(".csv"), os.listdir(self.csv_path))
        return csv_fils

    def get_details(self, file):
        return open(file).readlines()[1:]

    def main(self):
        for file in self.get_csv_files():
            if file == "fenzu1_3.csv":
                print self.get_details(os.path.join(self.csv_path, file))

HandleReport = HandleReport(r"C:\Users\chixiaobo\Desktop\try\1.2.1\20170627")
HandleReport.main()
