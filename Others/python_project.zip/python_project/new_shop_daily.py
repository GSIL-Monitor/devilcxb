# -*- coding: utf-8 -*-
import xlrd
import os
import datetime
import re
import xlwt


def convert_to_date(value):
    return "{}/{}/{}".format(value[0], value[1], value[2])


def get_latest_file(path):
    date = str(max(
        map(lambda x: datetime.datetime.strptime(re.match(".*shops_?(.*)_total\.xls", x).groups()[0], "%Y-%m-%d"),
            filter(lambda x: re.match("shops_.*total\.xls", x), os.listdir(path))))).split()[0]
    return "shops_{}_total.xls".format(date)

def write_excel(path, contents):
    wb = xlwt.Workbook()
    ws0 = wb.add_sheet('sheet0')
    count = 0
    fmt = 'YYYY/M/D'
    style = xlwt.XFStyle()
    style.num_format_str = fmt
    while count < len(contents):
        inter_count = 0
        while inter_count < len(contents[count]):
            if inter_count == 2:
                ws0.write(count, inter_count, contents[count][inter_count], style=style)
            else:
                ws0.write(count, inter_count, contents[count][inter_count])
            inter_count += 1
        count += 1
    wb.save(path)

province_map = {u"四川": 1,
                u"湖南": 2,
                u"广东": 3,
                u"山东": 4,
                u"深圳": 5,
                u"重庆": 6,
                u"北京": 7,
                u"浙江": 8,
                u"河北": 9,
                u"辽宁": 10,
                u"湖北": 11,
                u"河南": 12,
                u"上海": 13,
                u"陕西": 14,
                u"吉林": 15,
                u"贵州": 16,
                u"天津": 17,
                u"广西": 18,
                u"甘肃": 19,
                u"江西": 20,
                u"安徽": 21,
                u"江苏": 22,
                u"福建": 23,
                u"黑龙江": 24,
                u"云南": 25,
                u"山西": 26,
                }
province_map = {v: k for k, v in province_map.items()}

path = r"D:\Work\finance\new_shop"
newest_file = os.path.join(path, get_latest_file(path))
contents_total = map(lambda x: x, xlrd.open_workbook(newest_file).sheet_by_index(0).get_rows())
shops_from_all = map(lambda x: x[0].value, contents_total)
current_tickets = xlrd.open_workbook(os.path.join(path, "udticket.xls")).sheet_by_index(0).get_rows()
current_tickets = map(lambda x: x, current_tickets)[1:]
history_tickets = xlrd.open_workbook(os.path.join(path, "udticket_his.xls")).sheet_by_index(0).get_rows()
history_tickets = map(lambda x: x, history_tickets)[1:]
shops_from_history = map(lambda x: x[0].value, history_tickets)
filter_items = []
for item in current_tickets:
    if item[0].value not in shops_from_history:
        filter_items.append(item)
    elif item[2].value < history_tickets[shops_from_history.index(item[0].value)][2].value:
        history_tickets[shops_from_history.index(item[0].value)] = item
history_tickets = history_tickets + filter_items
shops_total_from_db = map(lambda x: x[0].value, history_tickets)
contents = []
print '"门店编号"', ',"地区"', ',"接入时间"'
for item in history_tickets:
    print item
    try:
        province_map[
            int(item[1].value.replace("xccoms", ""))]
    except KeyError:
        continue
    # content = [item[0].value ,province_map[
    #     int(item[1].value.replace("xccoms", ""))], convert_to_date(
    #     xlrd.xldate_as_tuple(item[2].value, 0))]
    content = [item[0].value ,province_map[
        int(item[1].value.replace("xccoms", ""))], item[2].value]
    if item[0].value not in shops_from_all:
        contents.append(content)
# 写文件
# open(os.path.join(path, "shops_{}_total.csv".format(datetime.datetime.now().strftime("%Y-%m-%d"))), "w").writelines(
#     contents + contents_total)
# open(os.path.join(path, "shops_{}_new.csv".format(datetime.datetime.now().strftime("%Y-%m-%d"))), "w").writelines(
#     contents)
contents_total = map(lambda x: map(lambda x: x.value, x), contents_total)
write_excel(os.path.join(path, "shops_{}_total.xls".format(datetime.datetime.now().strftime("%Y-%m-%d"))),
    contents + contents_total)
write_excel(os.path.join(path, "shops_{}_new.xls".format(datetime.datetime.now().strftime("%Y-%m-%d"))),
    contents)
