#!/usr/bin/env python
# -*- coding:utf-8 -*- 
# Author:  yangwei
# datetime:  2017/9/18
import socket

import time

import datetime

__author__ = 'yangwei'
from ftplib import FTP
import os

# ftp.set_debuglevel(0)  # 关闭调试模式
# ftp.dir()  # 显示目录下文件信息
# ftp.mkd('')  # 新建远程目录
# ftp.pwd()  # 返回当前所在位置
# ftp.rmd('')  # 删除远程目录
# ftp.delete(filename)  # 删除远程文件
# ftp.rename('', '')  # 将fromname修改名称为toname。


group_infos = {"218.6.173.206": [1, 6, 11, 16, 21, 41],
               "218.6.173.207": [2, 7, 12, 17, 22, 25],
               "218.6.173.209": [4, 9, 14, 19, 24],
               "218.6.173.210": [5, 10, 15, 20, 40],
               "ftp_path": "/LOGDATA/RETAILCOM{}"}


class FtpOperations(object):
    bufsize = 1024

    def __init__(self, IP, user, password, port="21"):
        self.ftp = FTP()  # 设置变量
        self.ftp.set_debuglevel(0)  # 打开调试级别2，显示详细信息
        self.ftp.connect(IP, port)  # 连接的ftp sever和端口
        self.ftp.login(user, password)  # 连接的用户名，密码
        print self.ftp.getwelcome()  # 打印出欢迎信息

    def uploadFiles(self, filename):
        """
            ftp上穿文件
        :param filename:
        """
        file_handle = open(filename, "wb").write
        self.ftp.storlines("STOR {}".format(filename), file_handle, self.bufsize)  # 上传目标文件

    def downloadFiles(self, filename, file_dir):
        """
            ftp下载制定的文件
        :param filename:
        :param file_dir:
        """
        file_path = os.path.join(file_dir, filename)
        file_handle = open(file_path, "wb").write
        # 以写模式在本地打开文件
        self.ftp.retrbinary("RETR {}".format(filename), file_handle, self.bufsize)

    # def exce_cmd(self,cmd):
    #     self.ftp.cwd(cmd)

    def get_dir_subfile_and_subdirs(self, dir):
        """
            获取ftp远程目录下所有文件和文件夹
        :param dir:
        :return:
        """
        dir_res = []
        self.change_ftp_dir(dir)
        self.ftp.dir('.', dir_res.append)
        files = [f.split(None, 8)[-1] for f in dir_res if f.startswith('-')]
        dirs = [f.split(None, 8)[-1] for f in dir_res if f.startswith('d')]
        return {"files": files, "dirs": dirs}

    def change_ftp_dir(self, dir):
        """
            切换ftp服务远程目录
        :param dir:
        """
        self.ftp.cwd(dir)  # 更改远程目录

    def quit(self):
        """
            ftp链接退出
        """
        if self.ftp:
            self.ftp.quit()  # 退出ftp


def compare_date(s1, s2):
    """
        获取两个日期的天数差
    :param s1:
    :param s2:
    :return:
    # s1 = '20120125'
    # s2 = '20120216'
    """
    a = time.strptime(s1, '%Y%m%d')
    b = time.strptime(s2, '%Y%m%d')
    a_datetime = datetime.datetime(*a[:3])
    b_datetime = datetime.datetime(*b[:3])
    return (b_datetime - a_datetime).days


def get_days_log_file(day, log_file_date):
    """
        从当前日期开始计算，判断是否是为制定天数之前的日志文件
    :param day:
    :param log_file_date:
    :return:
    """
    now_date_str = time.strftime('%Y%m%d', time.localtime(time.time()))
    return 0 <= compare_date(log_file_date, now_date_str) <= int(day)


def delete_all_file_and_subdirs(path):
    import shutil
    shutil.rmtree(path)


def new_dirs(path):
    if not os.path.exists(path) or not os.path.isdir(path):
        os.mkdir(path)


def downlaod_log_files(group, days=0, account="", user='xcftp',
                       local_root_path='product_logs/coms{}',
                       password='YaTangXc2017'):
    """
        从ftp路径下下载文件，可以制定从当前日期开始往前推多少天
    :param group:分组编号
    :param days: 获取几天前的日志文件
    :param account: 加盟商编号
    :param user:
    :param local_root_path:
    :param password:
    """
    if not local_root_path:
        local_root_path = local_root_path.format(group)
    if os.path.exists(local_root_path):
        delete_all_file_and_subdirs(local_root_path)
    new_dirs(local_root_path)
    ip = ''
    for key, value in group_infos.items():
        if isinstance(value, list):
            if group in value:
                ip = key
                break
    if not ip:
        print u"输入的分组不正确"
        return
    ftp_dir = group_infos.get('ftp_path').format(group)
    ftp_client = FtpOperations(ip, user, password)
    ftp_client.change_ftp_dir(ftp_dir)
    print ftp_client.ftp.pwd()
    file_and_dirs = ftp_client.get_dir_subfile_and_subdirs(ftp_dir)
    for remote_dir_name in file_and_dirs.get('dirs'):  # 遍历分组中商家存放日志文件夹
        dir_path = os.path.join(local_root_path, remote_dir_name)  # 本地文件夹路径
        log_files_dir = os.path.join(ftp_dir, remote_dir_name).replace('\\', '/')
        if account and not account == log_files_dir.split("/")[-1]:
            continue
        if not (os.path.exists(dir_path) and os.path.isdir(dir_path)):
            os.mkdir(dir_path)
        ftp_client.change_ftp_dir(log_files_dir)
        # 遍历下载每个商家上传的日志文件
        for filename_tmp in ftp_client.get_dir_subfile_and_subdirs(log_files_dir).get('files', []):
            try:
                log_file_path = os.path.join(dir_path, filename_tmp)
                log_file_date = filename_tmp.split("_")[1].replace("-", "") if len(filename_tmp.split("_")) > 1 else ""
                if not (os.path.exists(log_file_path) and os.path.isfile(log_file_path)) and get_days_log_file(
                        days, log_file_date):
                    ftp_client.downloadFiles(filename_tmp, dir_path)
            except socket.error, err:
                print err.message
                ftp_client.quit()
                ftp_client = FtpOperations(ip, user, password)
                ftp_client.change_ftp_dir(log_files_dir)
                ftp_client.downloadFiles(filename_tmp, dir_path)
        if account:
            break
    ftp_client.quit()


if __name__ == '__main__':
    downlaod_log_files(5, 4, "A000357")
    # print compare_date("20170925", "20170927")
