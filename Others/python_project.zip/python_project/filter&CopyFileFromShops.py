import os
import shutil
import xlrd

path = r"C:\Users\chixiaobo\Desktop\test1"
xls_files = filter(lambda x: x.endswith("xlsx"), os.listdir(path))
shop_folder = r"D:\Devil\python_project\swiftShops_20171115\zipfiles"
jpg_files = filter(lambda x: x.endswith("jpg"), os.listdir(shop_folder))
for xls_file in xls_files:
    xls_folder = os.path.join(path, xls_file.replace(".xlsx", ""))
    if not os.path.isdir(xls_folder):
        os.mkdir(xls_folder)
    shops = map(lambda x: x, map(lambda x: x[2].value, xlrd.open_workbook(os.path.join(path, xls_file)).sheet_by_index(0).get_rows())[2:])
    for shop in shops:
        copy_file = filter(lambda x: str(shop) in x, jpg_files)
        if copy_file:
            copy_file = copy_file[0]
            shutil.copy(os.path.join(shop_folder, copy_file), os.path.join(xls_folder, copy_file))
        else:
            print "{} is not existed from ".format(shop), xls_file.decode("gb2312")