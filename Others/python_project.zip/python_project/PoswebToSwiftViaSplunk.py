# -*- coding: utf-8 -*-
import re
import collections

with open("1508136492_2768.csv") as f:
    contents = f.read()
results = re.findall("\[(\d{4}-\d{1,2}-\d{1,2} \d{1,2}:\d{1,2}:\d{1,2},\d+)\].*?连接时间：(\d+).*?交易号：(\w+)", contents, re.S)
# print results
timeout_results = filter(lambda x: int(x[1]) >= 14800, results)
normal_results = filter(lambda x: int(x[1]) < 14800, results)
average_request_time = sum(map(lambda x: int(x[1]), normal_results))/len(normal_results)
print u"超过1.5S平均响应时间为： {}".format(average_request_time)
print u"超过1.5S最大响应时间为： {}".format(max(map(lambda x: int(x[1]), normal_results)))
print u"超过1.5S的请求数量为： {}".format(len(normal_results))
count = 2
while count < 15:
    print u"超过{}S的请求数量为： {}".format(count, len(filter(lambda x: int(x[1]) > count*1000, normal_results)))
    count += 1
print u"超过15S的请求数量为： {}".format(len(timeout_results))
shops = map(lambda x: x[2][:7], timeout_results)
shops_map = collections.Counter(shops)
for i in shops_map:
    print i
for i in shops_map:
    print shops_map[i]
# for timeout_result in timeout_results:
#     print timeout_result[1][:-1]

# print len(timeout_results)
# print reduce(lambda x, y: x + ',' + y, map(lambda x: "'" + x[1][:-1] + "'", timeout_results[: 999]))
# print reduce(lambda x, y: x + ',' + y, map(lambda x: "'" + x[1][:-1] + "'", timeout_results[999:]))