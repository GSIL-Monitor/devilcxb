# -*- coding: utf-8 -*-
from selenium import webdriver
import os
import time
import urllib
import urllib2
import datetime
import sys
from selenium.webdriver.support.select import Select
count_total = 0
while True:
    try:
        browser = webdriver.Ie()
        browser.get("http://xcapi.yatang.cn/account/index.jsp")
        browser.maximize_window()
        browser.find_element_by_id("username").send_keys("admin")
        browser.find_element_by_id("password").send_keys("kL6!KxP%")
        browser.find_element_by_class_name("loginBtn").click()
        count = 1
        while not browser.find_element_by_class_name("icon-home"):
            count +=1
            if count == 10:
                print "home page can not open!"
                sys.exit(1)
        browser.get("http://xcapi.yatang.cn/coms2/index.jsp")
        tags_a = browser.find_elements_by_tag_name("a")
        for tag_a in tags_a:
            if tag_a.text == u"报表":
                tag_a.click()
                break
        tags_li = browser.find_elements_by_tag_name("li")
        for tag_li in tags_li:
            if tag_li.text == u"加盟商结算汇总":
                tag_li.click()
                break
        time.sleep(1)
        browser.switch_to.frame("contIFrame")
        dealStatus = browser.find_element_by_id("dealStatus")
        # dealStatus.click()
        # tags_option = dealStatus.find_elements_by_tag_name("option")
        Select(dealStatus).select_by_value("3")
        tags_button = browser.find_elements_by_class_name("ButtonStyle")
        for tag_button in tags_button:
            if tag_button.get_property("value") == u"查询":
                tag_button.click()
                break
        tbody_id = browser.find_element_by_id("ec_table_body")
        tags_td = browser.find_elements_by_tag_name("td")
        for tag_td in tags_td:
            if u"接口签名验证失败" in tag_td.text:
                import sendMail
                break
        browser.close()
        count_total += 1
        print count_total,datetime.datetime.now()
        time.sleep(60*30)
        # cookie = browser.get_cookies()[0]
        # cookie_name = cookie["name"]
        # cookie_value = cookie["value"]
        # print cookie_name
        # print cookie_value
        # headers = {
        #     "User-Agent":	"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
        #     "Cookie": "{}={}".format(cookie_name, cookie_value)
        # }
        # data = {"alliBusiName": "",
        #         "shopDesc": "",
        #        "location": "",
        #         "locationid": "",
        #         "dealStatus" : "3",
        #         "commitDateStart": "",
        #         "commitDateEnd" : "",
        #         "timeType": "",
        #        "dealDate": "",
        #         "dealEndDate": ""}
        # query_url = "http://xcapi.yatang.cn/coms2/dealFinanceAction.do?method=doQuery"
        # data = urllib.urlencode(data)
        # Req = urllib2.Request(query_url, headers=headers)
        # print urllib2.urlopen(Req, data=data).read()
    except:
        pass