# -*- coding: utf8 -*-
import re
import datetime
import json
import urllib2
import xlrd
import urllib
import xlwt


def get_bank_code():
    a = u"""
                        
                              <option value="10000088">阿拉善左旗方大村镇银行</option>
                         
                              <option value="10000624">安徽省农村信用社联合社</option>
                         
                              <option value="10000333">安徽省农村信用社联合社</option>
                         
                              <option value="10000334">鞍山市商业银行</option>
                         
                              <option value="10000089">鞍山银行</option>
                         
                              <option value="321">包商银行</option>
                         
                              <option value="536">保定银行</option>
                         
                              <option value="10000068">宝生村镇银行</option>
                         
                              <option value="49">北京银行</option>
                         
                              <option value="361">北京农商银行</option>
                         
                              <option value="10000094">北京顺义银座村镇银行</option>
                         
                              <option value="10000062">北京农村商业银行股份有限公司</option>
                         
                              <option value="10000095">本溪市商业银行</option>
                         
                              <option value="221">渤海银行</option>
                         
                              <option value="10000033">沧州银行</option>
                         
                              <option value="581">朝阳银行</option>
                         
                              <option value="502">承德银行</option>
                         
                              <option value="261">成都银行</option>
                         
                              <option value="10000087">成都农商银行</option>
                         
                              <option value="10000102">达州市商业银行</option>
                         
                              <option value="10000103">大华银行</option>
                         
                              <option value="10000104">大连银行</option>
                         
                              <option value="10000105">大同银行</option>
                         
                              <option value="10000106">大新银行</option>
                         
                              <option value="10000107">丹东市商业银行</option>
                         
                              <option value="10000108">丹东银行</option>
                         
                              <option value="10000113">德阳银行</option>
                         
                              <option value="10000115">德州银行</option>
                         
                              <option value="48">东莞银行</option>
                         
                              <option value="43">东莞农村商业银行</option>
                         
                              <option value="10000118">东营莱商村镇银行</option>
                         
                              <option value="10000119">东营银行</option>
                         
                              <option value="10000120">都江堰金都村镇银行</option>
                         
                              <option value="10000121">鄂尔多斯银行</option>
                         
                              <option value="10000297">佛山市农村商业银行</option>
                         
                              <option value="10000406">福州农商行</option>
                         
                              <option value="10000302">福建农村信用社农商银行</option>
                         
                              <option value="10000127">福建海峡银行</option>
                         
                              <option value="10000128">抚顺银行</option>
                         
                              <option value="301">富滇银行</option>
                         
                              <option value="10000129">阜新银行</option>
                         
                              <option value="10000372">甘肃农村信用社</option>
                         
                              <option value="461">甘肃银行</option>
                         
                              <option value="10000131">赣州银行</option>
                         
                              <option value="10000432">古交市阜民村镇银行</option>
                         
                              <option value="10000132">固阳包商惠农村镇银行</option>
                         
                              <option value="10000315">广东省农村信用社联合社</option>
                         
                              <option value="10000332">广西省桂林市资源县农村信用合作社</option>
                         
                              <option value="10000335">广西农村信用社</option>
                         
                              <option value="504">广东南粤银行</option>
                         
                              <option value="183">广东华兴银行</option>
                         
                              <option value="12">广东发展银行</option>
                         
                              <option value="506">广州银行</option>
                         
                              <option value="10000133">广东顺德农村商业银行</option>
                         
                              <option value="10000135">广州农村商业银行</option>
                         
                              <option value="10000008">广西北部湾银行股份有限公司</option>
                         
                              <option value="10000373">贵州省农村信用社联合社</option>
                         
                              <option value="61">贵阳银行</option>
                         
                              <option value="382">桂林银行</option>
                         
                              <option value="10000072">桂银村镇银行</option>
                         
                              <option value="10000136">贵州银行</option>
                         
                              <option value="10000137">国家开发银行</option>
                         
                              <option value="526">哈尔滨银行股份有限公司</option>
                         
                              <option value="10000141">哈密市商业银行</option>
                         
                              <option value="10000336">海南省农村信用社</option>
                         
                              <option value="10000626">海南省农村信用社联合社</option>
                         
                              <option value="10000142">海口联合农村商业银行</option>
                         
                              <option value="401">邯郸银行</option>
                         
                              <option value="101">汉口银行</option>
                         
                              <option value="124">杭州联合银行</option>
                         
                              <option value="102">杭州联合农村商业银行</option>
                         
                              <option value="42">杭州银行</option>
                         
                              <option value="10000319">河北省农村信用社联合社</option>
                         
                              <option value="10000346">河南省农村信用社</option>
                         
                              <option value="10000382">河南巩义农村商业银行股份有限公司</option>
                         
                              <option value="10000427">河南永城农村商业银行股份有限公司</option>
                         
                              <option value="10000428">河南武陟农村商业银行股份有限公司</option>
                         
                              <option value="503">河北银行</option>
                         
                              <option value="10000311">黑龙江省农村信用社</option>
                         
                              <option value="561">恒丰银行</option>
                         
                              <option value="10000150">衡水银行</option>
                         
                              <option value="161">葫芦岛银行</option>
                         
                              <option value="508">葫芦岛市商业银行</option>
                         
                              <option value="10000337">湖北省农村信用社联合社</option>
                         
                              <option value="10000374">湖南省农村信用社联合社</option>
                         
                              <option value="10000151">湖北银行</option>
                         
                              <option value="10000152">湖州银行</option>
                         
                              <option value="10000345">户县海丝村镇银行</option>
                         
                              <option value="46">华夏银行</option>
                         
                              <option value="10000041">华润银行</option>
                         
                              <option value="10000154">华南商业银行</option>
                         
                              <option value="10000156">华融湘江银行</option>
                         
                              <option value="10000157">华商银行</option>
                         
                              <option value="142">徽商银行</option>
                         
                              <option value="10000623">吉林省农村信用社联合社</option>
                         
                              <option value="10000433">吉林双阳农村商业银行</option>
                         
                              <option value="10000158">吉林银行</option>
                         
                              <option value="10000160">济宁银行</option>
                         
                              <option value="10000161">嘉兴银行</option>
                         
                              <option value="10000075">建瓯村镇银行</option>
                         
                              <option value="10000032">江苏长江商业银行</option>
                         
                              <option value="10000313">江西省农村信用社联合社</option>
                         
                              <option value="10000339">江阴农商银行</option>
                         
                              <option value="10000378">江南农村商业银行</option>
                         
                              <option value="241">江苏银行</option>
                         
                              <option value="10000034">江苏江南农村商业银行股份有限公司</option>
                         
                              <option value="10000312">江苏省农村信用社联合社</option>
                         
                              <option value="10000327">江门新会农村商业银行股份有限公司</option>
                         
                              <option value="10000016">江西银行</option>
                         
                              <option value="10000163">江苏常熟农村商业银行</option>
                         
                              <option value="10000164">江苏江阴农村商业银行</option>
                         
                              <option value="10000165">江苏吴江农村商业银行</option>
                         
                              <option value="10000166">江西赣州银座村镇银行</option>
                         
                              <option value="10000614">焦作市商业银行</option>
                         
                              <option value="14">交通银行</option>
                         
                              <option value="10000167">焦作中旅银行</option>
                         
                              <option value="621">金华银行</option>
                         
                              <option value="10000422">金谷农商行</option>
                         
                              <option value="182">锦州银行</option>
                         
                              <option value="383">晋中银行</option>
                         
                              <option value="523">晋商银行</option>
                         
                              <option value="534">晋城银行</option>
                         
                              <option value="10000168">九江银行</option>
                         
                              <option value="10000169">库尔勒市商业银行</option>
                         
                              <option value="10000170">昆仑银行</option>
                         
                              <option value="10000171">昆山农村商业银行</option>
                         
                              <option value="528">莱州农村商业银行</option>
                         
                              <option value="10000172">莱商银行</option>
                         
                              <option value="10000007">兰州银行</option>
                         
                              <option value="122">廊坊银行</option>
                         
                              <option value="10000006">乐清农商银行</option>
                         
                              <option value="201">乐山市商业银行</option>
                         
                              <option value="10000173">凉山州商业银行</option>
                         
                              <option value="10000310">辽宁省农村信用社联合社</option>
                         
                              <option value="10000174">辽阳银行</option>
                         
                              <option value="10000344">临潼海丝村镇银行</option>
                         
                              <option value="10000176">临商银行</option>
                         
                              <option value="10000417">灵宝市农村信用合作联社</option>
                         
                              <option value="10000177">柳州银行</option>
                         
                              <option value="531">龙江银行</option>
                         
                              <option value="10000178">泸州市商业银行</option>
                         
                              <option value="262">洛阳银行</option>
                         
                              <option value="10000430">洛阳农商银行</option>
                         
                              <option value="10000180">漯河市商业银行</option>
                         
                              <option value="10000184">绵阳市商业银行</option>
                         
                              <option value="10000074">闽清村镇银行</option>
                         
                              <option value="10000342">闽清瑞狮村镇银行</option>
                         
                              <option value="10000002">南海农商银行</option>
                         
                              <option value="10000308">南昌银行</option>
                         
                              <option value="47">南京银行</option>
                         
                              <option value="10000039">南充市商业银行</option>
                         
                              <option value="10000186">南康赣商村镇银行</option>
                         
                              <option value="10000187">南阳银行</option>
                         
                              <option value="10000309">内蒙古自治区农村信用社联合社</option>
                         
                              <option value="505">内蒙古银行</option>
                         
                              <option value="121">宁夏银行股份有限公司</option>
                         
                              <option value="62">宁波银行</option>
                         
                              <option value="10000189">宁波东海银行</option>
                         
                              <option value="10000190">宁波通商银行</option>
                         
                              <option value="10000191">宁夏黄河农村商业银行</option>
                         
                              <option value="45">农村商业银行</option>
                         
                              <option value="10000194">攀枝花市商业银行</option>
                         
                              <option value="421">盘锦市商业银行</option>
                         
                              <option value="10000195">盘谷银行</option>
                         
                              <option value="11">平安银行</option>
                         
                              <option value="10000196">平顶山银行</option>
                         
                              <option value="10000197">平凉市商业银行</option>
                         
                              <option value="403">齐鲁银行</option>
                         
                              <option value="641">齐商银行</option>
                         
                              <option value="10000037">其它银行</option>
                         
                              <option value="10000293">秦皇岛银行</option>
                         
                              <option value="535">秦皇岛市商业银行</option>
                         
                              <option value="281">青岛银行</option>
                         
                              <option value="10000375">青海省农村信用社联合社</option>
                         
                              <option value="10000200">青海银行</option>
                         
                              <option value="10000201">琼海国民村镇银行</option>
                         
                              <option value="10000202">曲靖市商业银行</option>
                         
                              <option value="10000347">泉州农商银行</option>
                         
                              <option value="10000042">泉州银行</option>
                         
                              <option value="501">日照银行</option>
                         
                              <option value="10000404">三河蒙银村镇银行</option>
                         
                              <option value="10000343">三原海丝村镇银行</option>
                         
                              <option value="10000211">三门峡市商业银行</option>
                         
                              <option value="10000213">厦门银行</option>
                         
                              <option value="10000314">山东省农村信用社联合社</option>
                         
                              <option value="10000320">山西省农村信用社联合社</option>
                         
                              <option value="10000011">山东济南润丰农村合作银行</option>
                         
                              <option value="10000214">山口银行</option>
                         
                              <option value="10000318">陕西省农村信用社联合社</option>
                         
                              <option value="10000348">陕西秦农农村商业银行股份有限公司</option>
                         
                              <option value="10000215">商丘市商业银行</option>
                         
                              <option value="81">上海农商银行</option>
                         
                              <option value="8">上海浦东发展银行</option>
                         
                              <option value="141">上海银行</option>
                         
                              <option value="10000217">上海崇明长江村镇银行</option>
                         
                              <option value="10000218">上海商业银行</option>
                         
                              <option value="10000219">上饶银行</option>
                         
                              <option value="10000220">绍兴银行</option>
                         
                              <option value="10000292">深圳农村商业银行</option>
                         
                              <option value="9">深圳发展银行</option>
                         
                              <option value="10000221">深圳福田银座村镇银行</option>
                         
                              <option value="442">盛京银行</option>
                         
                              <option value="530">石狮农商银行</option>
                         
                              <option value="10000222">石嘴山银行</option>
                         
                              <option value="10000357">双流诚民村镇银行有限责任公司</option>
                         
                              <option value="10000038">顺德农商银行</option>
                         
                              <option value="10000631">四川省农村信用社联合社</option>
                         
                              <option value="44">苏州银行</option>
                         
                              <option value="10000352">遂宁银行</option>
                         
                              <option value="10000225">遂宁市商业银行</option>
                         
                              <option value="125">台州银行股份有限公司</option>
                         
                              <option value="41">台州商业银行</option>
                         
                              <option value="529">泰安市商业银行</option>
                         
                              <option value="10000226">太仓农村商业银行</option>
                         
                              <option value="10000228">泰华农民银行</option>
                         
                              <option value="10000229">唐山银行</option>
                         
                              <option value="10000377">天津市农村信用合作社</option>
                         
                              <option value="381">天津银行</option>
                         
                              <option value="10000230">天津滨海农村商业银行</option>
                         
                              <option value="10000231">天津农村商业银行</option>
                         
                              <option value="10000232">天津市蓟县村镇银行</option>
                         
                              <option value="10000233">铁岭银行</option>
                         
                              <option value="10000405">微众银行</option>
                         
                              <option value="10000234">威海市商业银行</option>
                         
                              <option value="527">潍坊银行</option>
                         
                              <option value="10000235">温州银行</option>
                         
                              <option value="10000236">文昌国民村镇银行</option>
                         
                              <option value="10000340">乌鲁木齐市商业银行</option>
                         
                              <option value="522">乌海银行</option>
                         
                              <option value="10000237">乌鲁木齐银行</option>
                         
                              <option value="10000001">芜湖津盛农村商业银行股份有限公司</option>
                         
                              <option value="10000238">无锡农村商业银行</option>
                         
                              <option value="10000026">武汉农村商业银行</option>
                         
                              <option value="601">西安银行</option>
                         
                              <option value="10000239">西藏银行</option>
                         
                              <option value="10000079">仙游村镇银行</option>
                         
                              <option value="10000242">湘乡市村镇银行</option>
                         
                              <option value="10000413">新疆农村商业银行</option>
                         
                              <option value="10000376">新疆维吾尔自治区农村信用社联合社</option>
                         
                              <option value="10000245">新疆汇和银行</option>
                         
                              <option value="10">兴业银行</option>
                         
                              <option value="521">邢台银行</option>
                         
                              <option value="10000247">修水九银村镇银行</option>
                         
                              <option value="10000248">雅安市商业银行</option>
                         
                              <option value="10000250">烟台银行</option>
                         
                              <option value="10000362">郾城包商村镇银行</option>
                         
                              <option value="10000040">洋县农村信用合作联社</option>
                         
                              <option value="10000251">阳泉市商业银行</option>
                         
                              <option value="10000027">伊川农商银行</option>
                         
                              <option value="10000252">宜宾市商业银行</option>
                         
                              <option value="10000253">宜兴阳羡村镇银行</option>
                         
                              <option value="10000256">鄞州银行</option>
                         
                              <option value="10000307">营口沿海银行</option>
                         
                              <option value="507">营口银行</option>
                         
                              <option value="10000080">永定村镇银行</option>
                         
                              <option value="10000261">玉溪市商业银行</option>
                         
                              <option value="10000316">云南省农村信用社联合社</option>
                         
                              <option value="10000262">枣庄银行</option>
                         
                              <option value="10000263">湛江市商业银行</option>
                         
                              <option value="443">张家口市商业银行</option>
                         
                              <option value="10000264">张家港农村商业银行</option>
                         
                              <option value="10000265">张家口银行</option>
                         
                              <option value="10000266">彰化商业银行</option>
                         
                              <option value="163">长沙银行</option>
                         
                              <option value="533">长安银行</option>
                         
                              <option value="10000063">长沙银行股份有限公司</option>
                         
                              <option value="10000267">长治银行</option>
                         
                              <option value="5">招商银行</option>
                         
                              <option value="341">兆丰村镇银行</option>
                         
                              <option value="10000317">浙江省农村信用社联合社</option>
                         
                              <option value="181">浙江泰隆商业银行</option>
                         
                              <option value="10000052">浙江农商银行</option>
                         
                              <option value="10000047">浙江银行股份有限公司</option>
                         
                              <option value="10000021">浙商银行</option>
                         
                              <option value="10000268">浙江稠州商业银行</option>
                         
                              <option value="10000269">浙江景宁银座村镇银行</option>
                         
                              <option value="10000270">浙江民泰商业银行</option>
                         
                              <option value="10000271">浙江三门银座村镇银行</option>
                         
                              <option value="10000368">正定农商行</option>
                         
                              <option value="441">郑州银行</option>
                         
                              <option value="10000275">中国进出口银行</option>
                         
                              <option value="10000276">中国农业发展银行</option>
                         
                              <option value="7">中国光大银行</option>
                         
                              <option value="2">中国银行</option>
                         
                              <option value="13">中信银行</option>
                         
                              <option value="1">中国工商银行</option>
                         
                              <option value="3">中国建设银行</option>
                         
                              <option value="4">中国农业银行</option>
                         
                              <option value="6">中国邮政储蓄银行</option>
                         
                              <option value="15">中国民生银行</option>
                         
                              <option value="422">中原银行</option>
                         
                              <option value="10000353">中山农村商业银行</option>
                         
                              <option value="10000289">自贡市商业银行</option><option value="10000282">重庆农村商业银行</option>
                         
                              <option value="10000283">重庆黔江银座村镇银行</option>
                         
                              <option value="10000284">重庆三峡银行</option>
                         
                              <option value="10000285">重庆银行</option>
                         
                              <option value="10000286">重庆渝北银座村镇银行</option>
                         
                              <option value="10000287">珠海华润银行</option>
                         
                              <option value="10000288">珠海南通银行</option>
                         
                              <option value="123">珠海农村商业银行</option>
                         
                              <option value="10000082">驻马店银行股份有限公司</option>"""

    bank_dict = {}
    for i in re.findall(u'\<option value="(\d+)"\>([\u4e00-\u9fa5]+)\</option\>', a, re.S):
        bank_dict[i[1]] = i[0]
    return bank_dict


def get_shops_info(xls_file):
    return map(lambda x: x, xlrd.open_workbook(xls_file).sheet_by_index(0).get_rows())[1:]

def get_first_row(xls_file):
    return map(lambda x: x, xlrd.open_workbook(xls_file).sheet_by_index(0).get_rows())[0]


def post_form(merchantId, principal, principalNumber, idCode, accountBank, accountNumber):
    null = None
    false = False
    true = True
    url = "https://mch.swiftpass.cn/cms/base/merchantProtocol/ecitic-weixi-pay/merchantInfo?merchantId={}&principal={}&principalNumber={}&idCode={}&accountBank={}&accountNumber={}".format(
        merchantId, principal, principalNumber, idCode, accountBank, accountNumber)
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0",
               "Accept": "application/json, text/javascript, */*; q=0.01",
               "Referer": "https://mch.swiftpass.cn/mobile/cms/base/merchantProtocol/ecitic-weixi-pay/addUI",
               "Content-Type": "application/json;charset=UTF-8"
               }
    req = urllib2.Request(url, headers=headers)
    try:
        json_result = eval(urllib2.urlopen(req).read())
    except:
        return
    return json_result

def write_excel(path, contents):
    wb = xlwt.Workbook()
    ws0 = wb.add_sheet('sheet0')
    count = 0
    print len(contents)
    while count < len(contents):
        inter_count = 0
        while inter_count < len(contents[count]):
            ws0.write(count, inter_count, contents[count][inter_count])
            inter_count += 1
        count += 1
    wb.save(path)

def post_contract(merchantId, principal, principalNumber, idCode, accountBank, accountNumber):
    null = None
    false = False
    true = True
    url = "https://mch.swiftpass.cn/cms/base/merchantProtocol/ecitic-weixi-pay/add"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0",
               "Accept": "application/json, text/javascript, */*; q=0.01",
               "Referer": "https://mch.swiftpass.cn/mobile/cms/base/merchantProtocol/ecitic-weixi-pay/addUI",
               "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
               }
    data = {

        "merchantId": merchantId,
        "principal": principal,
        "principalNumber": principalNumber,
        "idCode": idCode,
        "accountBank": accountBank,
        "accountNumber": accountNumber
    }
    req = urllib2.Request(url, data=urllib.urlencode(data), headers=headers)
    try:
        result = urllib2.urlopen(req).read()
        print result
        json_result = eval(result)
    except:
        return
    return json_result

if __name__ == '__main__':
    bank_dict = get_bank_code()
    first_row = map(lambda x: x.value, get_first_row("shops.xlsx"))
    first_row.append(u"结果")
    print first_row
    shops_info = map(lambda x: map(lambda y: y.value, x), get_shops_info("shops.xlsx"))
    banks = map(lambda x: x[8], shops_info)
    banks_from_swift = bank_dict.keys()
    # for bank in banks:
    #     if bank not in banks_from_swift:
    #         print bank

    count = 0
    while count < len(shops_info):
        shop = shops_info[count]
        merchantId = int(shop[0])
        principal = shop[4]
        principalNumber = shop[5]
        idCode = shop[6]
        accountBank = bank_dict[shop[8]]
        accountNumber = shop[9]
        print merchantId, principal.encode("utf-8"), principalNumber, idCode, accountBank, accountNumber
        result = post_form(merchantId, principal.encode("utf-8"), principalNumber, idCode, accountBank, accountNumber)
        msg = result['msg'].decode("utf-8")
        if msg == u"获取商户信息成功":
            print merchantId, principal.encode("utf-8"), principalNumber, idCode, accountBank, accountNumber
            result = post_contract(merchantId, principal.encode("utf-8"), principalNumber, idCode, accountBank, accountNumber)
            msg = result['msg'].decode("utf-8")
        shops_info[count].append(msg)
        count += 1
    shops_info.insert(0, first_row)
    write_excel("test.xls", shops_info)
