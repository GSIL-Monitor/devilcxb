# -*- coding: utf-8 -*-
import AddAccount


if __name__ == '__main__':
    main_domain = "https://xcapi.yatang.cn"
    province_map = {u"四川": 1,
                    u"湖南": 2,
                    u"广东": 3,
                    u"山东": 4,
                    u"深圳": 5,
                    u"重庆": 6,
                    u"北京": 7,
                    u"浙江": 8,
                    u"河北": 9,
                    u"辽宁": 10,
                    u"湖北": 11,
                    u"河南": 12,
                    u"上海": 13,
                    u"陕西": 14,
                    u"吉林": 15,
                    u"贵州": 16,
                    u"天津": 17,
                    u"广西": 18,
                    u"甘肃": 19,
                    u"江西": 20,
                    u"安徽": 21,
                    u"江苏": 22,
                    u"福建": 23,
                    u"黑龙江": 24
                    }
    account_map = {u"四川": "901001",
     u"湖南": "902003",
     u"广东": "903001",
     u"山东": "904001",
     u"深圳": "905001",
     u"重庆": "906001",
     u"北京": "907001",
     u"浙江": "908001",
     u"河北": "909001",
     u"辽宁": "910001",
     u"湖北": "911001",
     u"河南": "912001",
     u"上海": "913001",
     u"陕西": "914001",
     u"吉林": "915001",
     u"贵州": "916001",
     u"天津": "917001",
     u"广西": "918001",
     u"甘肃": "919001",
     u"江西": "920001",
     u"安徽": "921001",
     u"江苏": "922001",
     u"福建": "923001",
     u"黑龙江": "924001"
     }
    for key in province_map.keys():
        coms = province_map[key]
        account = account_map[key]
        CreateAccount = AddAccount.CreateAccount(username=account, password="666666", xls_file="jms.xlsx", main_domain=main_domain)
        data = {"alliBusiId": "",
                "factoryCode": "",
                "brandId": "",
                "process":	"0",
                "orderUnit":	"个",
                "itemFix": "",
                "saveAndAdd": "",
                "itemType":	"1",
                "numFlag": 	"0",
                "itemNum": "6970993940017",
                "itemDesc":	"雅堂小超购物袋（小号）",
                "guidePrice":	"0.1",
                "goodsCode": "",
                "taxRate": "",
                "brandName": "",
                "factoryName": "",
                "standardUnit": "",
                "packageSize": "",
                "processFlag":	"0",
                "expiratioDate": "",
                "itemTypecode": "",
                "remarks": ""
                }
        url = "http://xcapi.yatang.cn/coms{}/shopItemAction.do?method=doSave".format(coms)
        print key,  coms,  CreateAccount.request_url(url, data=data, headers=CreateAccount.headers)
        data["itemDesc"] = "雅堂小超购物袋（大号）"
        data["guidePrice"] = "0.2"
        data["itemNum"] = "6970993940024"
        print CreateAccount.request_url(url, data=data, headers=CreateAccount.headers)
        CreateAccount.close_broswer()
