# -*- coding: utf-8 -*-
import shutil
import os
import sys
import datetime


def create_dirs(des):
    folders = des.split(os.path.sep)
    print folders
    init_des = des
    des = os.path.join(folders[0] + os.path.sep, folders[1])
    count = 2
    while True:
        if des == init_des:
            if os.path.isdir(init_des):
                pass
            else:
                os.mkdir(init_des)
            print "{} folder is created finished!".format(init_des)
            break
        if os.path.isdir(des):
            pass
        else:
            os.mkdir(des)
            print "{} is created!".format(des)
        des = os.path.join(des, folders[count])
        count += 1

def copy(files, src, des):
    for File in files:
        File = File.replace("/", "\\")
        if os.path.isfile(des + File):
            os.remove(des + File)
            print File + " is removed!"
        try:
            shutil.copy(src + File, des + File)
        except IOError:
            create_dirs(os.path.abspath(os.path.dirname(des + File)+os.path.sep+"."))
            shutil.copy(src + File, des + File)
        print File + " is copied!"


def check_commit_files(path, src_code_files):
    result = []
    for root, dirs, files in os.walk(path, True):
        if files:
            for File in files:
                result.append(os.path.join(root, File).replace(path, "").replace("\\", "/"))
    for i in result:
        if i not in src_code_files:
            print "{}".format(i)
        else:
            print "OK"

def commit_file(des, files, commit_msg):
    for file in files:
        os.system("svn commit --file {} --message {}".format(os.path.join(des, file), commit_msg))

def revert_revision(self, source_rev, des_rev, files, path):
    for File in files:
        os.system("svn merge -r {}:{} {}".format(source_rev, des_rev, os.path.join(path, File)))

def main(root_source, root_des, system, files, merge=True, check=False, commit=False, commit_files_root=None, commit_msg=None):
    if system == 'omp':
        src = os.path.join(root_source, 'dhc-omp')
        des = os.path.join(root_des, 'yt-omp')
    elif system == 'coms':
        src = os.path.join(root_source, 'yt-coms')
        des = os.path.join(root_des, 'yt-coms')
    elif system == 'posweb':
        src = os.path.join(root_source, 'yt-posweb')
        des = os.path.join(root_des, 'yt-posweb')
    elif system == 'sync':
        src = os.path.join(root_source, 'dhc-sync')
        des = os.path.join(root_des, 'yt-sync')
    elif system == 'sso':
        src = os.path.join(root_source, 'yt-sso')
        des = os.path.join(root_des, 'yt-sso')
    elif system == 'account':
        src = os.path.join(root_source, 'yt-account')
        des = os.path.join(root_des, 'yt-account')
    elif system == 'pos':
        src = os.path.join(root_source, 'iRetail-Pos-Dev-yt')
        des = os.path.join(root_des, 'iRetail-Pos-Dev-yt')
    else:
        sys.exit("no system is defined!")
    if merge:
        copy(files, src, des)
        if commit:
            commit_file(des, files, commit_msg)
    elif check:
        result = check_commit_files(commit_files_root, files)



if __name__ == '__main__':
    root_source = r"D:\projects_svn\suppermarket_dev\trunk\Code"
    root_des = r"D:\projects_svn\suppermarket_prd"
    code_files = r"""
/src/com/dhc/ipos/retail/conf/POS_SALEBILL_HANGON_DETAIL_T.xml
/src/com/dhc/ipos/retail/conf/UD_TICKET_LINE_T.xml
/src/com/dhc/ipos/retail/dao/ISaleBillHangOnDetailDao.as
/src/com/dhc/ipos/retail/dao/ITicketDetailDao.as
/src/com/dhc/ipos/retail/dao/impl/SaleBillHangOnDetailDaoImpl.as
/src/com/dhc/ipos/retail/dao/impl/TicketDetailDaoImpl.as
/src/com/dhc/ipos/retail/service/impl/SaleBillHangOnServiceImpl.as
/src/com/dhc/ipos/retail/service/impl/TicketServiceImpl.as
/src/com/dhc/ipos/retail/vo/TicketDetailInfo.as
    """
    commit_files_root = r'C:\Users\chixiaobo\Desktop\test'
    code_files = map(lambda x: x.strip(), list(set(code_files.split("\n")[1:-1])))
    merge = False
    commit=True
    commit_msg = "V2.0.1 {}".format(datetime.datetime.now())
    check = True
    # if not check:
    #     os.system(r"cd {}&&{}&&svn update".format(root_source, root_source.split(os.sep)[0]))
    system = "sync"
    main(root_source=root_source, root_des=root_des, system=system, files=code_files, merge=merge, commit=commit, check=check, commit_files_root=commit_files_root, commit_msg=commit_msg)

