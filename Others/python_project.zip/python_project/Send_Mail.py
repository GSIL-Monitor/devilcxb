#!/usr/bin/python
# -*- coding: UTF-8 -*-

import smtplib
from email.mime.text import MIMEText
from email.header import Header

# 第三方 SMTP 服务
mail_host = "smtp.yatang.cn"  # 设置服务器
mail_user = "chixiaobo@yatang.cn"  # 用户名
mail_pass = "DEVIL_cxb789"  # 口令

sender = 'chixiaobo@yatang.cn'
receivers = ["chixiaobo@yatang.cn"]  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱
cc = []
subject = 'dealStatus_failure!!!!'
message_text = 'failure'
message = "From: %s\r\n" % "Chi Xiaobo" + "To: %s\r\n" % ",".join(receivers) + "CC: %s\r\n" % ",".join(
    cc) + "Subject: %s\r\n" % subject + "\r\n" + '提测的内容：<br /><br />修复的bug:<br />NLS-454<br />NLS-627<br />NLS-640<br />NLS-602<br />NLS-598<br />NLS-591<br />NLS-585<br />NLS-577<br />NLS-417<br />NLS-410<br />NLS-393<br />NLS-316<br />NLS-261<br />NLS-247<br />NLS-208<br />NLS-448<br /><br />备注内容：<br /><br /><br />APK_URL:<br /><a href=http://retail-sit1.yatang.com.cn:8089/job/android_apk/26/artifact/NLSPOSAndroid_V1.0.0_2_Debug.apk target="_blank">http://retail-sit1.yatang.com.cn:8089/job/android_apk/26/artifact/NLSPOSAndroid_V1.0.0_2_Debug.apk </a>'

# from test import ProxSMTP
# smtpObj = ProxSMTP(p_address="swg.tieto.com", p_port=8080)
smtpObj = smtplib.SMTP_SSL(host=mail_host, port=465)
# smtpObj.connect(mail_host, 465)    # 25 为 SMTP 端口号
smtpObj.login(mail_user, mail_pass)
print message

smtpObj.sendmail(sender, receivers + cc, message)
print "邮件发送成功"
